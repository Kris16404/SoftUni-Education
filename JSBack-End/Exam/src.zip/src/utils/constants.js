const constants = {
  PORT: '3000',
  DB_STRING: 'mongodb://127.0.0.1:27017/second-hands-electronics',
  SECRET: '7e4324ee-6cbe-4148-b1dc-62a717c503eb',
};

module.exports = constants;
